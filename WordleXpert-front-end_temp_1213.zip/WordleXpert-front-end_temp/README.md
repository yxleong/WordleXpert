# WordleXpert
This repository hosts the final project for the CS2005701 Windows Programming course at NTUST (National Taiwan University of Science and Technology): WordleXpert. An advanced version of the classic Wordle game, featuring increased difficulty, multiple word lengths, new challenges, and a flexible GUI for a personalized experience.
