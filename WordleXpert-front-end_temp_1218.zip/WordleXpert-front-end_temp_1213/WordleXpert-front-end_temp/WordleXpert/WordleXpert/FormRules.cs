﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordleXpert
{
    public partial class FormRules : Form
    {
        public FormRules()
        {
            InitializeComponent();

            if (Program.RuleIsCh) displayChRule();
        }

        private void btnLanguage_Click(object sender, EventArgs e)
        {
            if (Program.RuleIsCh) displayEngRule();
            else displayChRule();

            // update state
            Program.RuleIsCh = !Program.RuleIsCh;
        }

        private void displayChRule() {
            btnLanguage.Text = "En";
            // change text

        }

        private void displayEngRule() {
            btnLanguage.Text = "中";
            // change text

        }
    }
}
