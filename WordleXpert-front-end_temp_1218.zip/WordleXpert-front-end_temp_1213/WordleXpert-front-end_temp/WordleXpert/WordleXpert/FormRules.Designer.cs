﻿namespace WordleXpert
{
    partial class FormRules
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLanguage = new System.Windows.Forms.Button();
            this.picTitle = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(picTitle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLanguage
            // 
            this.btnLanguage.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLanguage.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnLanguage.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnLanguage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLanguage.Location = new System.Drawing.Point(280, 19);
            this.btnLanguage.Name = "btnLanguage";
            this.btnLanguage.Size = new System.Drawing.Size(34, 33);
            this.btnLanguage.TabIndex = 14;
            this.btnLanguage.Text = "中";
            this.btnLanguage.UseVisualStyleBackColor = false;
            this.btnLanguage.Click += new System.EventHandler(this.btnLanguage_Click);
            // 
            // picTitle
            // 
            this.picTitle.BackgroundImage = global::WordleXpert.Properties.Resources.howToPlay_label;
            this.picTitle.Location = new System.Drawing.Point(42, 25);
            this.picTitle.Name = "picTitle";
            this.picTitle.Size = new System.Drawing.Size(196, 22);
            this.picTitle.TabIndex = 13;
            this.picTitle.TabStop = false;
            // 
            // FormRules
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(377, 450);
            this.Controls.Add(btnLanguage);
            this.Controls.Add(picTitle);
            this.Name = "FormRules";
            this.Text = "How To Play";
            ((System.ComponentModel.ISupportInitialize)(picTitle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox picTitle;
        private System.Windows.Forms.Button btnLanguage;

    }
}